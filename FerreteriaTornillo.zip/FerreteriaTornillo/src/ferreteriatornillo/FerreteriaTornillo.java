
package ferreteriatornillo;

import ferreteriatornillo.UserInterfaces.FrmLogin;

public class FerreteriaTornillo {
    

    public static void main(String[] args) {
        FrmLogin frmLogin = new FrmLogin();
        frmLogin.setVisible(true);
        frmLogin.setLocationRelativeTo(null);
    }
    
}
