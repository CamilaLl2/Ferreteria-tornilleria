
package ferreteriatornillo.Logic;

public class Admin extends Users {
    
    public Admin(String id, String name, String password) {
        super(id, name, password);
    }
}
