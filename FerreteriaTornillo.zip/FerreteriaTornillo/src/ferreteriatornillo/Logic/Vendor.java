
package ferreteriatornillo.Logic;

public class Vendor extends Users {
    
    public Vendor(String id, String name, String password) {
        super(id, name, password);
    }
    
}
