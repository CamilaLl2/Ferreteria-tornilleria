
package ferreteriatornillo.Logic;

public class Customer extends Users {
    
    public Customer(String id, String name, String password) {
        super(id, name, password);
    }
    
}
